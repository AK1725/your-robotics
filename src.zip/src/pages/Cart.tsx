import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Minus, Plus, Trash2, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import api from "@/services/api";

interface CartItem {
  _id: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
  stock: number;
}

export default function Cart() {
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [couponCode, setCouponCode] = useState("");
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);

  // Fetch cart on mount
  useEffect(() => {
    api.get("/api/cart")
      .then(res => setCartItems(res.data))
      .catch(err => console.error(err));
  }, []);

  // Update quantity handler
  const updateQuantity = (itemId: string, newQty: number) => {
    api.put(`/api/cart/${itemId}`, { quantity: newQty })
      .then(res => setCartItems(res.data))
      .catch(() =>
        toast({
          title: "Update failed",
          description: "Could not update item quantity",
          variant: "destructive",
        })
      );
  };

  // Remove item handler
  const removeItem = (itemId: string) => {
    api.delete(`/api/cart/${itemId}`)
      .then(res => setCartItems(res.data))
      .catch(() =>
        toast({
          title: "Remove failed",
          description: "Could not remove item",
          variant: "destructive",
        })
      );
  };

  // Apply coupon handler
  const handleApplyCoupon = () => {
    if (!couponCode.trim()) return;
    setIsApplyingCoupon(true);
    api.post("/api/cart/apply-coupon", { code: couponCode })
      .then(res => {
        setCartItems(res.data);
        toast({ title: "Coupon applied", description: "Discount updated." });
      })
      .catch(() =>
        toast({
          title: "Invalid coupon",
          description: "The coupon code you entered is invalid or expired.",
          variant: "destructive",
        })
      )
      .finally(() => setIsApplyingCoupon(false));
  };

  // Totals
  const subtotal = cartItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shipping = subtotal > 100 ? 0 : 9.99;
  const tax = subtotal * 0.07;
  const total = subtotal + shipping + tax;
  const formatTaka = (usd: number) =>
    `৳${Math.round(usd * 110).toLocaleString()}`;

  return (
    <div className="container-custom py-8">
      {/* ...breadcrumb omitted for brevity */}
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          {/* empty state UI */}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Items list */}
          <div className="lg:col-span-2 space-y-6">
            {cartItems.map(item => (
              <div key={item._id} className="grid sm:grid-cols-5 gap-4 py-4 border-b">
                {/* ...image/title */}
                <div className="text-center">
                  {formatTaka(item.price)}
                </div>
                <div className="flex items-center justify-center">
                  <button onClick={() => updateQuantity(item._id, item.quantity - 1)}>
                    <Minus />
                  </button>
                  <span className="px-3">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item._id, item.quantity + 1)}>
                    <Plus />
                  </button>
                </div>
                <div className="text-right">
                  {formatTaka(item.price * item.quantity)}
                </div>
                <button onClick={() => removeItem(item._id)}>
                  <Trash2 />
                </button>
              </div>
            ))}
            <Button asChild variant="outline">
              <Link to="/products">Continue Shopping</Link>
            </Button>
          </div>

          {/* Summary */}
          <div>
            <Card>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatTaka(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? "Free" : formatTaka(shipping)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (7%)</span>
                    <span>{formatTaka(tax)}</span>
                  </div>
                  <div className="border-t pt-3 flex justify-between font-bold">
                    <span>Total</span>
                    <span>{formatTaka(total)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    placeholder="Coupon code"
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                  />
                  <Button
                    onClick={handleApplyCoupon}
                    disabled={isApplyingCoupon}
                  >
                    {isApplyingCoupon ? "Applying…" : "Apply"}
                  </Button>
                </div>
                <Button asChild className="w-full">
                  <Link to="/checkout">Proceed to Checkout</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
