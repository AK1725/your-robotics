import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { ChevronRight, CreditCard, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import api from "@/services/api";

interface CartItem {
  _id: string;
  name: string;
  price: number;
  quantity: number;
}

export default function Checkout() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [shippingMethod, setShippingMethod] = useState("standard");
  const [paymentMethod, setPaymentMethod] = useState("credit-card");
  // form fields…
  const [firstName, setFirstName] = useState("");
  // …lastName, email, address, city, state, zipCode, phone

  useEffect(() => {
    api.get("/api/cart")
      .then(res => setCartItems(res.data))
      .catch(err => console.error(err));
  }, []);

  const subtotal = cartItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shippingCost = shippingMethod === "express" ? 14.99 : (subtotal > 100 ? 0 : 9.99);
  const tax = subtotal * 0.07;
  const total = subtotal + shippingCost + tax;
  const formatTaka = (usd: number) => `৳${Math.round(usd * 110).toLocaleString()}`;

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      await api.post("/api/orders", {
        cartItems,
        shippingInfo: { firstName, /*…*/ phone },
        shippingMethod,
        paymentMethod,
      });
      toast({ title: "Order placed!", description: "Thank you for your purchase." });
      navigate("/order-confirmation");
    } catch {
      toast({
        title: "Order failed",
        description: "Something went wrong, please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="container-custom py-8">
      {/* …breadcrumb omitted */}
      <form onSubmit={handlePlaceOrder} className="grid lg:grid-cols-3 gap-8">
        {/* Left: forms (shipping, method, payment) */}
        <div className="lg:col-span-2 space-y-8">
          {/* Shipping Info card */}
          <Card>
            <CardContent>
              <h2 className="text-xl font-bold flex items-center mb-4">
                <Package className="mr-2" /> Shipping Information
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    required
                  />
                </div>
                {/* …other inputs */}
              </div>
            </CardContent>
          </Card>

          {/* Shipping Method */}
          <Card>
            <CardContent>
              <h2 className="text-xl font-bold mb-4">Shipping Method</h2>
              <RadioGroup
                value={shippingMethod}
                onValueChange={setShippingMethod}
              >
                <div className="p-4 border rounded mb-2 flex justify-between">
                  <RadioGroupItem value="standard" id="standard" />
                  <Label htmlFor="standard" className="flex-1 ml-2 cursor-pointer">
                    Standard (3–5 days)
                  </Label>
                  <span>{shippingCost === 0 ? "Free" : formatTaka(shippingCost)}</span>
                </div>
                <div className="p-4 border rounded flex justify-between">
                  <RadioGroupItem value="express" id="express" />
                  <Label htmlFor="express" className="flex-1 ml-2 cursor-pointer">
                    Express (1–2 days)
                  </Label>
                  <span>{formatTaka(14.99)}</span>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card>
            <CardContent>
              <h2 className="text-xl font-bold flex items-center mb-4">
                <CreditCard className="mr-2" /> Payment Method
              </h2>
              {/* Tabs or radio for credit-card, bkash, nagad… */}
              {/* For brevity, use paymentMethod state similarly */}
            </CardContent>
          </Card>
        </div>

        {/* Right: order summary */}
        <div className="sticky top-20">
          <Card>
            <CardContent>
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{formatTaka(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>{formatTaka(shippingCost)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax (7%)</span>
                  <span>{formatTaka(tax)}</span>
                </div>
                <div className="border-t pt-3 flex justify-between font-bold">
                  <span>Total</span>
                  <span>{formatTaka(total)}</span>
                </div>
              </div>
              <Button
                type="submit"
                className="w-full mt-4"
                disabled={isProcessing}
              >
                {isProcessing ? "Processing…" : "Place Order"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
);
}
